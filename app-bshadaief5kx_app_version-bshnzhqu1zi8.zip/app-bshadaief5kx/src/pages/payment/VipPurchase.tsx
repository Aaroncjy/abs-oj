import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Check, Crown, Loader2 } from "lucide-react";
import { toast } from "sonner";
import QRCodeDataUrl from "@/components/ui/qrcodedataurl";

export default function VipPurchase() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [skus, setSkus] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  
  // Payment Dialog State
  const [payUrl, setPayUrl] = useState("");
  const [orderNo, setOrderNo] = useState("");
  const [showQR, setShowQR] = useState(false);

  useEffect(() => {
    async function loadSkus() {
      try {
        const { data, error } = await supabase.from('sku').select('*').like('sku_code', 'VIP_%').order('price', { ascending: true });
        if (error) throw error;
        setSkus(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadSkus();
  }, []);

  // Poll order status
  useEffect(() => {
    let interval: number;
    if (showQR && orderNo) {
      interval = setInterval(async () => {
        const { data } = await supabase.from('orders').select('status').eq('order_no', orderNo).single();
        if (data && data.status === 'paid') {
          clearInterval(interval);
          setShowQR(false);
          toast.success("支付成功！您已成为 VIP");
          // Refresh page or user profile to reflect VIP status
          window.location.reload();
        }
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [showQR, orderNo]);

  const handlePurchase = async (skuCode: string) => {
    if (!user) {
      toast.error("请先登录");
      navigate("/login");
      return;
    }

    setProcessingId(skuCode);
    try {
      const { data, error } = await supabase.functions.invoke('create_payment_order', {
        body: { sku_code: skuCode, quantity: 1 }
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      setOrderNo(data.order_no);
      setPayUrl(data.url);
      setShowQR(true);
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "创建支付订单失败，请检查微信支付配置。");
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div className="container py-12 max-w-5xl mx-auto px-4">
      <div className="text-center mb-12 space-y-4">
        <h1 className="text-4xl font-bold flex items-center justify-center gap-2">
          <Crown className="h-10 w-10 text-yellow-500" />
          升级 VIP 会员
        </h1>
        <p className="text-xl text-muted-foreground">解锁全部 6000+ 题目，享受 AI 智能答疑等专属特权</p>
        
        {profile?.is_vip && (
          <div className="inline-block bg-yellow-500/10 text-yellow-600 px-4 py-2 rounded-full font-medium mt-4 border border-yellow-500/20">
            您当前是 VIP 会员，到期时间：{new Date(profile.vip_expire_time).toLocaleDateString()}
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
        {loading ? (
          <div className="col-span-3 text-center py-12">加载中...</div>
        ) : skus.map((sku) => (
          <Card key={sku.id} className={`flex flex-col relative overflow-hidden ${sku.sku_code === 'VIP_3_MONTH' ? 'border-primary shadow-lg scale-105 z-10' : ''}`}>
            {sku.sku_code === 'VIP_3_MONTH' && (
              <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-3 py-1 text-xs font-bold rounded-bl-lg">
                最受欢迎
              </div>
            )}
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-2xl">{sku.name.replace('VIP会员 ', '')}</CardTitle>
              <CardDescription>解锁所有特权</CardDescription>
            </CardHeader>
            <CardContent className="text-center flex-1">
              <div className="my-4">
                <span className="text-4xl font-bold">¥{sku.price}</span>
              </div>
              <ul className="space-y-3 text-sm text-left mt-6">
                <li className="flex items-center"><Check className="h-4 w-4 text-green-500 mr-2" /> 访问全部 6000+ 题库</li>
                <li className="flex items-center"><Check className="h-4 w-4 text-green-500 mr-2" /> 无限次 AI 答疑助手</li>
                <li className="flex items-center"><Check className="h-4 w-4 text-green-500 mr-2" /> 高级图片生成特权</li>
                <li className="flex items-center"><Check className="h-4 w-4 text-green-500 mr-2" /> 做题记录导出文档</li>
                <li className="flex items-center"><Check className="h-4 w-4 text-green-500 mr-2" /> 专属 VIP 身份标识</li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full" 
                variant={sku.sku_code === 'VIP_3_MONTH' ? 'default' : 'outline'}
                onClick={() => handlePurchase(sku.sku_code)}
                disabled={processingId === sku.sku_code}
              >
                {processingId === sku.sku_code ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                {profile?.is_vip ? '立即续费' : '立即开通'}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Dialog open={showQR} onOpenChange={setShowQR}>
        <DialogContent className="sm:max-w-md flex flex-col items-center justify-center p-8">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">微信扫码支付</DialogTitle>
            <DialogDescription className="text-center">订单号: {orderNo}</DialogDescription>
          </DialogHeader>
          <div className="my-8 p-4 bg-white rounded-xl shadow-sm border">
             <QRCodeDataUrl data={payUrl} width={200} height={200} />
          </div>
          <p className="text-sm text-muted-foreground animate-pulse">正在等待支付结果...</p>
        </DialogContent>
      </Dialog>
    </div>
  );
}
