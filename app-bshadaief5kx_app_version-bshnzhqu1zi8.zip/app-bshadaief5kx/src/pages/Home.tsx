import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Code, Trophy, Users, MessageSquare } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col flex-1">
      <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-muted/40">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-balance">
                专注提升您的编程能力
              </h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl text-balance">
                6000+ 题库、在线编译、AI 答疑、团队协作与比赛。加入 ABSOJ，开始你的编程大师之路。
              </p>
            </div>
            <div className="space-x-4">
              <Button asChild size="lg">
                <Link to="/problems">开始刷题</Link>
              </Button>
              <Button variant="outline" asChild size="lg">
                <Link to="/register">免费注册</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
      
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div className="flex flex-col items-center space-y-3 text-center border p-6 rounded-lg bg-card">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Code className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">海量题库</h3>
              <p className="text-sm text-muted-foreground">
                超过 6000 道精选编程与客观题，支持在线编译执行，即时反馈判题结果。
              </p>
            </div>
            <div className="flex flex-col items-center space-y-3 text-center border p-6 rounded-lg bg-card">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Trophy className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">竞技比赛</h3>
              <p className="text-sm text-muted-foreground">
                参与团队或个人比赛，实时更新排行榜，赢取专属勋章与金币奖励。
              </p>
            </div>
            <div className="flex flex-col items-center space-y-3 text-center border p-6 rounded-lg bg-card">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">团队协作</h3>
              <p className="text-sm text-muted-foreground">
                创建或加入学习团队，共享团队题库，组队参与比赛，共同成长。
              </p>
            </div>
            <div className="flex flex-col items-center space-y-3 text-center border p-6 rounded-lg bg-card">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <MessageSquare className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">互动社区与 AI</h3>
              <p className="text-sm text-muted-foreground">
                在论坛讨论交流，使用智能 AI 助手实时答疑，提供代码优化建议。
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
