export default function Placeholder({ title }: { title: string }) {
  return (
    <div className="flex flex-1 items-center justify-center p-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold">{title}</h2>
        <p className="text-muted-foreground mt-2">此页面正在开发中...</p>
      </div>
    </div>
  );
}
