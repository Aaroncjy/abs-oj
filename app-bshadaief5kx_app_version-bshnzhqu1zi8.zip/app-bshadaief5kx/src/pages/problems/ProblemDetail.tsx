import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Play, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from 'react-markdown';

export default function ProblemDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [problem, setProblem] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  const [code, setCode] = useState("");
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<any>(null);

  useEffect(() => {
    async function loadProblem() {
      if (!id) return;
      try {
        const { data, error } = await supabase.from('problems').select('*').eq('id', id).single();
        if (error) throw error;
        setProblem(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadProblem();
  }, [id]);

  const handleSubmit = async () => {
    if (!user) {
      toast.error("请先登录");
      return;
    }

    setSubmitting(true);
    setResult({ status: 'compiling' });
    
    try {
      // Create pending submission
      const { data: sub, error: subError } = await supabase.from('submissions').insert({
        user_id: user.id,
        problem_id: id,
        code: problem.type === 'programming' ? code : selectedOption,
        status: 'pending'
      }).select().single();

      if (subError) throw subError;

      // Simulate compilation and judging
      await new Promise(r => setTimeout(r, 1500));
      
      let isCorrect = false;
      if (problem.type === 'programming') {
        // Mock compiler logic
        isCorrect = code.trim().length > 10; 
      } else {
        isCorrect = parseInt(selectedOption) === problem.correct_option;
      }

      const status = isCorrect ? 'passed' : 'failed';
      
      // Update submission
      await supabase.from('submissions').update({
        status,
        time_used: isCorrect ? Math.floor(Math.random() * 50) + 10 : null,
        memory_used: isCorrect ? Math.floor(Math.random() * 1024) + 512 : null
      }).eq('id', sub.id);

      setResult({
        status,
        message: isCorrect ? '代码执行成功，所有测试用例通过！' : '解答错误，请重试。',
        time: isCorrect ? '15ms' : null,
        memory: isCorrect ? '2.1MB' : null
      });

      if (isCorrect) {
        toast.success("恭喜，解答正确！获得 10 金币！");
        // Add gold
        await supabase.rpc('add_coins', { user_id_in: user.id, amount: 10 });
      } else {
        toast.error("解答错误");
      }

    } catch (err: any) {
      setResult({ status: 'error', message: err.message || '提交过程发生异常' });
      toast.error("提交失败");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="flex h-screen items-center justify-center">加载中...</div>;
  if (!problem) return <div className="flex h-screen items-center justify-center">未找到题目</div>;

  return (
    <div className="flex flex-1 flex-col md:flex-row h-[calc(100vh-4rem)] overflow-hidden">
      {/* Left panel: Description */}
      <div className="flex-1 w-full md:w-1/2 border-r overflow-y-auto bg-background p-6">
        <div className="max-w-3xl mx-auto space-y-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-2xl font-bold">{problem.title}</h1>
              <Badge variant={problem.difficulty === 'easy' ? 'secondary' : problem.difficulty === 'medium' ? 'default' : 'destructive'}>
                {problem.difficulty === 'easy' ? '简单' : problem.difficulty === 'medium' ? '中等' : '困难'}
              </Badge>
            </div>
            <div className="flex gap-4 text-sm text-muted-foreground">
              <span>提交：{problem.submit_count}</span>
              <span>通过率：{problem.submit_count > 0 ? Math.round((problem.passed_count / problem.submit_count) * 100) : 0}%</span>
            </div>
          </div>
          
          <div className="prose dark:prose-invert max-w-none">
            <ReactMarkdown>{problem.description}</ReactMarkdown>
          </div>
        </div>
      </div>

      {/* Right panel: Editor / Options */}
      <div className="flex-1 w-full md:w-1/2 flex flex-col bg-muted/20">
        <div className="flex-1 p-4 overflow-y-auto">
          {problem.type === 'programming' ? (
            <div className="h-full flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-sm text-muted-foreground">代码编辑器</span>
              </div>
              <Textarea 
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="// 在此编写您的代码"
                className="flex-1 font-mono resize-none bg-background shadow-inner"
              />
            </div>
          ) : (
            <div className="p-4 bg-background rounded-lg border">
              <h3 className="font-semibold mb-4">选择正确答案</h3>
              <RadioGroup value={selectedOption} onValueChange={setSelectedOption}>
                {problem.options?.map((opt: string, idx: number) => (
                  <div key={idx} className="flex items-center space-x-2 p-3 rounded hover:bg-muted/50 transition-colors">
                    <RadioGroupItem value={idx.toString()} id={`opt-${idx}`} />
                    <Label htmlFor={`opt-${idx}`} className="flex-1 cursor-pointer">{String.fromCharCode(65 + idx)}. {opt}</Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}
        </div>
        
        {/* Output Panel */}
        <div className="h-48 border-t bg-background p-4 flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <span className="font-semibold text-sm">运行结果</span>
            <Button onClick={handleSubmit} disabled={submitting || (problem.type === 'programming' ? !code.trim() : !selectedOption)}>
              {submitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
              {submitting ? "执行中..." : "提交代码"}
            </Button>
          </div>
          <div className="flex-1 rounded border bg-muted/50 p-4 overflow-y-auto font-mono text-sm">
            {!result ? (
              <span className="text-muted-foreground">请执行代码查看结果</span>
            ) : result.status === 'compiling' ? (
              <div className="flex items-center text-primary">
                <Loader2 className="w-4 h-4 mr-2 animate-spin" /> 正在编译运行...
              </div>
            ) : result.status === 'passed' ? (
              <div className="space-y-2">
                <div className="flex items-center text-green-600 font-bold">
                  <CheckCircle2 className="w-5 h-5 mr-2" /> 通过
                </div>
                <div className="text-muted-foreground">执行用时: {result.time}</div>
                <div className="text-muted-foreground">消耗内存: {result.memory}</div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center text-destructive font-bold">
                  <XCircle className="w-5 h-5 mr-2" /> 解答错误
                </div>
                <div className="text-destructive/80">{result.message}</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
