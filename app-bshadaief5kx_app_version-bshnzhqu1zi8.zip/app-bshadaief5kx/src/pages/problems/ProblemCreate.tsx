import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";

export default function ProblemCreate() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [type, setType] = useState("programming");
  
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    difficulty: "easy",
    standard_answer: "",
    options: ["", "", "", ""],
    correct_option: "0"
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!formData.title || !formData.description) {
      toast.error("请填写必填项");
      return;
    }

    setLoading(true);
    try {
      const payload: any = {
        title: formData.title,
        description: formData.description,
        difficulty: formData.difficulty,
        type: type,
        created_by: user.id
      };

      if (type === 'programming') {
        payload.standard_answer = formData.standard_answer;
        payload.test_cases = [{ input: "1 2", output: "3" }]; // Mock test case
      } else {
        payload.options = formData.options.filter(o => o.trim() !== "");
        payload.correct_option = parseInt(formData.correct_option);
      }

      const { data, error } = await supabase.from('problems').insert(payload).select().single();
      if (error) throw error;
      
      toast.success("题目创建成功");
      navigate(`/problems/${data.id}`);
    } catch (err: any) {
      toast.error(err.message || "创建失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">创建题目</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={type} onValueChange={setType} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="programming">编程题</TabsTrigger>
              <TabsTrigger value="objective">客观题</TabsTrigger>
            </TabsList>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label>题目标题 *</Label>
                <Input 
                  value={formData.title} 
                  onChange={(e) => setFormData({...formData, title: e.target.value})} 
                  placeholder="例如：两数之和"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>难度 *</Label>
                  <Select 
                    value={formData.difficulty} 
                    onValueChange={(v) => setFormData({...formData, difficulty: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="选择难度" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">简单</SelectItem>
                      <SelectItem value="medium">中等</SelectItem>
                      <SelectItem value="hard">困难</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>题目描述 (支持 Markdown) *</Label>
                <Textarea 
                  value={formData.description} 
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="在此输入题目详情..."
                  className="min-h-[200px]"
                  required
                />
              </div>

              <TabsContent value="programming" className="space-y-6 mt-0">
                <div className="space-y-2">
                  <Label>标准代码答案</Label>
                  <Textarea 
                    value={formData.standard_answer} 
                    onChange={(e) => setFormData({...formData, standard_answer: e.target.value})}
                    placeholder="参考实现代码..."
                    className="min-h-[200px] font-mono"
                  />
                </div>
              </TabsContent>

              <TabsContent value="objective" className="space-y-6 mt-0">
                <div className="space-y-4">
                  <Label>选项设置</Label>
                  {[0, 1, 2, 3].map((index) => (
                    <div key={index} className="flex items-center gap-4">
                      <div className="w-8 text-center font-medium">
                        {String.fromCharCode(65 + index)}.
                      </div>
                      <Input 
                        value={formData.options[index]}
                        onChange={(e) => {
                          const newOpts = [...formData.options];
                          newOpts[index] = e.target.value;
                          setFormData({...formData, options: newOpts});
                        }}
                        placeholder={`选项 ${index + 1}`}
                      />
                    </div>
                  ))}
                </div>
                <div className="space-y-2">
                  <Label>正确选项</Label>
                  <Select 
                    value={formData.correct_option} 
                    onValueChange={(v) => setFormData({...formData, correct_option: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="选择正确答案" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">A</SelectItem>
                      <SelectItem value="1">B</SelectItem>
                      <SelectItem value="2">C</SelectItem>
                      <SelectItem value="3">D</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>

              <div className="flex justify-end gap-4 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => navigate(-1)}>取消</Button>
                <Button type="submit" disabled={loading}>
                  {loading ? "保存中..." : "保存题目"}
                </Button>
              </div>
            </form>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
