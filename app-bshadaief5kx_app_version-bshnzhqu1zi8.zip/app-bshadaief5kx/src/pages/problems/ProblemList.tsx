import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Plus, Lock } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function ProblemList() {
  const { profile } = useAuth();
  const [problems, setProblems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    async function loadProblems() {
      try {
        let query = supabase.from('problems').select('*').order('created_at', { ascending: false });
        if (search) {
          query = query.ilike('title', `%${search}%`);
        }
        const { data, error } = await query.limit(50);
        if (error) throw error;
        setProblems(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadProblems();
  }, [search]);

  return (
    <div className="container py-8 max-w-6xl mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <h1 className="text-3xl font-bold">题库</h1>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="搜索题目..."
              className="pl-8"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          {profile && (
            <Button asChild>
              <Link to="/problems/create">
                <Plus className="mr-2 h-4 w-4" /> 创建题目
              </Link>
            </Button>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="w-full max-w-full overflow-x-auto bg-card">
            <Table className="[&>div]:max-w-full min-w-max">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px] whitespace-nowrap">状态</TableHead>
                  <TableHead className="whitespace-nowrap">标题</TableHead>
                  <TableHead className="w-[100px] whitespace-nowrap">难度</TableHead>
                  <TableHead className="w-[100px] whitespace-nowrap text-right">通过率</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">加载中...</TableCell>
                  </TableRow>
                ) : problems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">暂无题目</TableCell>
                  </TableRow>
                ) : (
                  problems.map((p, index) => {
                    // Logic to simulate VIP restriction: Let's say index > 10 requires VIP
                    const requireVip = index > 10 && !profile?.is_vip && profile?.role !== 'admin';
                    
                    return (
                      <TableRow key={p.id}>
                        <TableCell className="whitespace-nowrap">
                          {/* Unsolved/Solved status icon here */}
                          <span className="text-muted-foreground">-</span>
                        </TableCell>
                        <TableCell className="whitespace-nowrap font-medium">
                          {requireVip ? (
                            <div className="flex items-center text-muted-foreground">
                              <Lock className="w-4 h-4 mr-2" />
                              <span>{p.title}</span>
                              <Badge variant="outline" className="ml-2 bg-yellow-500/10 text-yellow-600 border-yellow-500/20">VIP</Badge>
                            </div>
                          ) : (
                            <Link to={`/problems/${p.id}`} className="hover:text-primary transition-colors">
                              {p.title}
                            </Link>
                          )}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge variant={p.difficulty === 'easy' ? 'secondary' : p.difficulty === 'medium' ? 'default' : 'destructive'}>
                            {p.difficulty === 'easy' ? '简单' : p.difficulty === 'medium' ? '中等' : '困难'}
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-right text-muted-foreground">
                          {p.submit_count > 0 ? Math.round((p.passed_count / p.submit_count) * 100) : 0}%
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
