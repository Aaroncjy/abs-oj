import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from 'react-markdown';

export default function PostDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [post, setPost] = useState<any>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyContent, setReplyContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  
  // AI assistant state
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState("");

  useEffect(() => {
    async function loadData() {
      if (!id) return;
      try {
        const [{ data: pData }, { data: cData }] = await Promise.all([
          supabase.from('posts').select('*, profiles(username, avatar_url)').eq('id', id).single(),
          supabase.from('comments').select('*, profiles(username, avatar_url)').eq('post_id', id).order('created_at', { ascending: true })
        ]);
        setPost(pData);
        setComments(cData || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [id]);

  const handleReply = async () => {
    if (!user) {
      toast.error("请先登录");
      return;
    }
    if (!replyContent.trim()) return;

    setSubmitting(true);
    try {
      const { data, error } = await supabase.from('comments').insert({
        post_id: id,
        author_id: user.id,
        content: replyContent
      }).select('*, profiles(username, avatar_url)').single();

      if (error) throw error;
      
      await supabase.from('posts').update({ reply_count: (post.reply_count || 0) + 1 }).eq('id', id);
      
      setComments([...comments, data]);
      setReplyContent("");
      toast.success("回复成功");
    } catch (err: any) {
      toast.error("回复失败: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAskAI = async () => {
    if (!user) {
      toast.error("请先登录");
      return;
    }
    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('baidu-ai-search', {
        body: {
          messages: [{ role: "user", content: `请基于以下帖子内容给出专业回答或建议：标题：${post.title}，内容：${post.content}` }],
          enable_deep_search: false
        }
      });
      
      // baidu-ai-search returns an SSE stream typically, but let's assume we can get a simple JSON for this MVP
      // Wait, baidu-ai-search is an SSE stream. We need to handle it using standard fetch.
      // Let's implement a simplified fetch for SSE.
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/baidu-ai-search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({
          messages: [{ role: "user", content: `请针对此贴回复：${post.title}\n\n${post.content}` }]
        })
      });
      
      if (!response.ok) throw new Error("AI 请求失败");
      
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = "";
      
      if (reader) {
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          for (const line of lines) {
            if (line.startsWith('data: ') && line !== 'data: [DONE]') {
              try {
                const parsed = JSON.parse(line.slice(6));
                if (parsed.choices?.[0]?.delta?.content) {
                  fullText += parsed.choices[0].delta.content;
                  setAiResponse(fullText);
                }
              } catch (e) {}
            }
          }
        }
      }
    } catch (err: any) {
      toast.error("调用 AI 失败: " + err.message);
    } finally {
      setAiLoading(false);
    }
  };

  if (loading) return <div className="text-center py-12">加载中...</div>;
  if (!post) return <div className="text-center py-12">帖子不存在</div>;

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4 space-y-6">
      <Card>
        <CardContent className="p-6 md:p-8">
          <div className="flex items-center gap-2 mb-4">
            <Badge variant="outline">{post.category === 'site' ? '站务' : post.category === 'academic' ? '学术' : '娱乐'}</Badge>
            <h1 className="text-2xl md:text-3xl font-bold">{post.title}</h1>
          </div>
          
          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-8 border-b pb-4">
            <div className="flex items-center gap-2">
              <img src={post.profiles?.avatar_url || "/default-avatar.png"} className="w-6 h-6 rounded-full bg-muted" alt="" />
              <Link to={`/profile/${post.author_id}`} className="hover:text-primary">{post.profiles?.username}</Link>
            </div>
            <span>{new Date(post.created_at).toLocaleString()}</span>
          </div>

          <div className="prose dark:prose-invert max-w-none mb-8">
            <ReactMarkdown>{post.content}</ReactMarkdown>
          </div>
          
          <div className="flex justify-end pt-4 border-t">
            <Button variant="outline" onClick={handleAskAI} disabled={aiLoading}>
              <Bot className="w-4 h-4 mr-2" />
              {aiLoading ? "AI 思考中..." : "召唤 AI 助手答疑"}
            </Button>
          </div>
          
          {aiResponse && (
            <div className="mt-4 p-4 bg-primary/5 rounded-lg border border-primary/20">
              <div className="flex items-center gap-2 text-primary font-bold mb-2">
                <Bot className="w-5 h-5" /> AI 助手回答
              </div>
              <div className="prose dark:prose-invert max-w-none text-sm">
                <ReactMarkdown>{aiResponse}</ReactMarkdown>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h3 className="text-lg font-bold flex items-center gap-2">
          <MessageCircle className="w-5 h-5" /> 回复 ({comments.length})
        </h3>
        
        {comments.map((comment) => (
          <Card key={comment.id}>
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                <img src={comment.profiles?.avatar_url || "/default-avatar.png"} className="w-6 h-6 rounded-full bg-muted" alt="" />
                <Link to={`/profile/${comment.author_id}`} className="font-medium hover:text-primary text-foreground">
                  {comment.profiles?.username}
                </Link>
                <span>•</span>
                <span>{new Date(comment.created_at).toLocaleString()}</span>
              </div>
              <div className="text-sm">
                {comment.content}
              </div>
            </CardContent>
          </Card>
        ))}

        <Card>
          <CardContent className="p-4 md:p-6 space-y-4">
            <Textarea 
              placeholder="写下你的回复..." 
              value={replyContent}
              onChange={(e) => setReplyContent(e.target.value)}
              className="min-h-[100px]"
            />
            <div className="flex justify-end">
              <Button onClick={handleReply} disabled={submitting || !replyContent.trim()}>
                发表回复
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
