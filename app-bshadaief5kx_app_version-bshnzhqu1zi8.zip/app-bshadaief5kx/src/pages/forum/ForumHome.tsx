import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MessageSquare, Plus, MessageCircle, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function ForumHome() {
  const [category, setCategory] = useState("all");
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadPosts() {
      setLoading(true);
      try {
        let query = supabase.from('posts').select('*, profiles(username, avatar_url)').order('created_at', { ascending: false });
        if (category !== "all") {
          query = query.eq('category', category);
        }
        const { data, error } = await query.limit(50);
        if (error) throw error;
        setPosts(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadPosts();
  }, [category]);

  const categoryMap: Record<string, string> = {
    'site': '站务',
    'academic': '学术',
    'entertainment': '娱乐'
  };

  return (
    <div className="container py-8 max-w-5xl mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <MessageSquare className="h-8 w-8 text-primary" />
          社区论坛
        </h1>
        <Button asChild>
          <Link to="/forum/create">
            <Plus className="mr-2 h-4 w-4" /> 发布帖子
          </Link>
        </Button>
      </div>

      <Tabs value={category} onValueChange={setCategory} className="w-full mb-6">
        <TabsList>
          <TabsTrigger value="all">全部</TabsTrigger>
          <TabsTrigger value="site">站务</TabsTrigger>
          <TabsTrigger value="academic">学术</TabsTrigger>
          <TabsTrigger value="entertainment">娱乐</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">加载中...</div>
        ) : posts.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center h-48 text-muted-foreground">
              <MessageSquare className="h-8 w-8 mb-2 opacity-50" />
              暂无帖子
            </CardContent>
          </Card>
        ) : (
          posts.map(post => (
            <Card key={post.id} className="hover:border-primary/50 transition-colors">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4 justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{categoryMap[post.category]}</Badge>
                      <Link to={`/forum/${post.id}`} className="text-xl font-semibold hover:text-primary transition-colors">
                        {post.title}
                      </Link>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <img src={post.profiles?.avatar_url || "/default-avatar.png"} className="w-4 h-4 rounded-full bg-muted" alt="" />
                        {post.profiles?.username || "未知用户"}
                      </span>
                      <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {new Date(post.created_at).toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" />
                      {post.reply_count}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
