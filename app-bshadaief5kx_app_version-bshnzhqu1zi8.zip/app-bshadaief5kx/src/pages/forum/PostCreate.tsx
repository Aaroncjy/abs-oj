import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";

export default function PostCreate() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error("请先登录");
      return;
    }
    if (!formData.title || !formData.content || !formData.category) {
      toast.error("请填写全部必填项");
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.from('posts').insert({
        title: formData.title,
        content: formData.content,
        category: formData.category,
        author_id: user.id
      }).select().single();

      if (error) throw error;
      
      toast.success("帖子发布成功");
      navigate(`/forum/${data.id}`);
    } catch (err: any) {
      toast.error(err.message || "发布失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">发布新帖</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label>帖子标题 *</Label>
              <Input 
                value={formData.title} 
                onChange={(e) => setFormData({...formData, title: e.target.value})} 
                placeholder="一句话描述你的问题或分享..."
                required
              />
            </div>

            <div className="space-y-2">
              <Label>板块选择 *</Label>
              <Select 
                value={formData.category} 
                onValueChange={(v) => setFormData({...formData, category: v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="请选择板块" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="academic">学术 (编程讨论、求助)</SelectItem>
                  <SelectItem value="site">站务 (建议、反馈、公告)</SelectItem>
                  <SelectItem value="entertainment">娱乐 (划水、灌水)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>内容 (支持 Markdown) *</Label>
              <Textarea 
                value={formData.content} 
                onChange={(e) => setFormData({...formData, content: e.target.value})}
                placeholder="在此输入详细内容..."
                className="min-h-[300px] font-mono text-sm"
                required
              />
            </div>

            <div className="flex justify-end gap-4 pt-4 border-t">
              <Button type="button" variant="outline" onClick={() => navigate(-1)}>取消</Button>
              <Button type="submit" disabled={loading}>
                {loading ? "发布中..." : "发表帖子"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
