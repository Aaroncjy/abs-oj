import { useState, useRef, useCallback } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/db/supabase";
import { toast } from "sonner";
import { Camera } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  
  // Face recognition states
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const streamRef = useRef<MediaStream | null>(null);

  const from = location.state?.from || "/";

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("请输入邮箱和密码");
      return;
    }
    
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: email,
        password,
      });

      if (error) {
        toast.error(error.message === "Invalid login credentials" ? "邮箱或密码错误" : error.message);
      } else {
        toast.success("登录成功");
        navigate(from);
      }
    } catch (err: any) {
      toast.error(err.message || "登录失败");
    } finally {
      setLoading(false);
    }
  };

  const startCamera = async () => {
    setCameraError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsCameraActive(true);
      }
    } catch (err) {
      setCameraError("无法访问摄像头，请检查权限设置");
      toast.error("无法访问摄像头");
    }
  };

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  }, []);

  const handleFaceLogin = async () => {
    if (!videoRef.current || !canvasRef.current || !isCameraActive) return;

    setLoading(true);
    try {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      if (!context) throw new Error("Could not get canvas context");

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      const base64Image = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];

      // Call face-search edge function
      const { data, error } = await supabase.functions.invoke('face-search', {
        body: {
          image: base64Image,
          image_type: "BASE64",
          liveness_control: "NORMAL",
          quality_control: "NORMAL",
        }
      });

      if (error) throw error;

      if (data.error_code === 0 && data.result?.user_list && data.result.user_list.length > 0) {
        const userList = data.result.user_list;
        const matchedUser = userList[0];
        
        if (matchedUser.score > 80) {
          // Found a match! We need a custom mechanism to log them in since Supabase 
          // doesn't natively support face login. We would ideally have an edge function
          // that returns a custom JWT or magic link based on the face_id (matchedUser.user_id).
          // For now, we'll simulate a magic link approach or show a message.
          toast.info("人脸识别成功！由于平台限制，这里需要配置相应的认证网关。目前暂只支持邮箱密码登录。");
          stopCamera();
        } else {
          toast.error("人脸识别分数过低，请正对摄像头重试");
        }
      } else {
        toast.error(data.error_msg || "未找到匹配的人脸记录");
      }
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "人脸识别过程发生错误");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-1 items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-2xl font-bold">欢迎回来</CardTitle>
          <CardDescription>选择一种方式登录您的账号</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="email" className="w-full" onValueChange={(v) => {
            if (v !== 'face' && isCameraActive) stopCamera();
          }}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="email">邮箱登录</TabsTrigger>
              <TabsTrigger value="face">人脸识别登录</TabsTrigger>
            </TabsList>
            
            <TabsContent value="email">
              <form onSubmit={handleEmailLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">邮箱</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="name@example.com" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">密码</Label>
                    <Link to="#" className="text-xs text-primary hover:underline">忘记密码？</Link>
                  </div>
                  <Input 
                    id="password" 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required 
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "登录中..." : "登录"}
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="face">
              <div className="flex flex-col items-center space-y-4">
                <div className="relative w-full max-w-[300px] aspect-square bg-muted rounded-lg overflow-hidden border flex items-center justify-center">
                  {!isCameraActive ? (
                    <div className="flex flex-col items-center text-muted-foreground p-4 text-center">
                      <Camera className="h-12 w-12 mb-2" />
                      <p className="text-sm">点击下方按钮开启摄像头</p>
                      {cameraError && <p className="text-xs text-destructive mt-2">{cameraError}</p>}
                    </div>
                  ) : (
                    <video 
                      ref={videoRef} 
                      autoPlay 
                      playsInline 
                      muted 
                      className="w-full h-full object-cover transform -scale-x-100" 
                    />
                  )}
                  <canvas ref={canvasRef} className="hidden" />
                </div>
                
                {!isCameraActive ? (
                  <Button onClick={startCamera} className="w-full" variant="outline">
                    开启摄像头
                  </Button>
                ) : (
                  <div className="flex gap-2 w-full">
                    <Button onClick={stopCamera} variant="outline" className="flex-1">
                      取消
                    </Button>
                    <Button onClick={handleFaceLogin} className="flex-1" disabled={loading}>
                      {loading ? "识别中..." : "开始识别"}
                    </Button>
                  </div>
                )}
                <p className="text-xs text-muted-foreground text-center">
                  请正对摄像头，保持光线充足。需先在设置中绑定人脸。
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-center text-sm text-muted-foreground">
            还没有账号？{" "}
            <Link to="/register" className="text-primary hover:underline font-medium">
              立即注册
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
