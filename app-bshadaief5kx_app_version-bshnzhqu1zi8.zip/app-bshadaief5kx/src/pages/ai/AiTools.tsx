import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Image as ImageIcon, Search, CloudSun, FileDown, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/db/supabase";
import { useAuth } from "@/contexts/AuthContext";

export default function AiTools() {
  const { user, profile } = useAuth();
  
  // Image Gen State
  const [imagePrompt, setImagePrompt] = useState("");
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generatedImage, setGeneratedImage] = useState("");

  // Weather State
  const [districtId, setDistrictId] = useState("110100"); // Beijing default
  const [isCheckingWeather, setIsCheckingWeather] = useState(false);
  const [weatherData, setWeatherData] = useState<any>(null);

  const checkVip = () => {
    if (!profile?.is_vip && profile?.role !== 'admin') {
      toast.error("此功能需要 VIP 特权");
      return false;
    }
    return true;
  };

  const handleGenerateImage = async () => {
    if (!checkVip()) return;
    if (!imagePrompt.trim()) return;

    setIsGeneratingImage(true);
    try {
      const { data, error } = await supabase.functions.invoke('image-generations', {
        body: { prompt: imagePrompt, size: "1024x1024" }
      });
      if (error) throw error;
      
      if (data && data.data && data.data[0] && data.data[0].b64_json) {
        setGeneratedImage(`data:image/png;base64,${data.data[0].b64_json}`);
        toast.success("图片生成成功");
      } else {
        throw new Error("返回格式异常");
      }
    } catch (err: any) {
      toast.error("生成失败: " + err.message);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleCheckWeather = async () => {
    setIsCheckingWeather(true);
    try {
      const { data, error } = await supabase.functions.invoke('district-weather', {
        body: { district_id: districtId, data_type: "now" }
      });
      if (error) throw error;
      
      if (data && data.status === 0 && data.result) {
        setWeatherData(data.result);
        toast.success("查询成功");
      } else {
        throw new Error("查询异常");
      }
    } catch (err: any) {
      toast.error("查询失败: " + err.message);
    } finally {
      setIsCheckingWeather(false);
    }
  };

  const handleExportDoc = () => {
    if (!checkVip()) return;
    toast.success("文档导出任务已提交（模拟）");
  };

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">AI 工具箱</h1>
      
      <Tabs defaultValue="image" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="image"><ImageIcon className="w-4 h-4 mr-2"/> 图片生成</TabsTrigger>
          <TabsTrigger value="weather"><CloudSun className="w-4 h-4 mr-2"/> 天气查询</TabsTrigger>
          <TabsTrigger value="doc"><FileDown className="w-4 h-4 mr-2"/> 文档导出</TabsTrigger>
        </TabsList>
        
        <TabsContent value="image">
          <Card>
            <CardHeader>
              <CardTitle>AI 图片生成</CardTitle>
              <CardDescription>VIP专属：输入描述，生成高质量图片</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea 
                placeholder="描述你想要的画面，例如：一个赛博朋克风格的程序员在敲代码..."
                value={imagePrompt}
                onChange={(e) => setImagePrompt(e.target.value)}
                className="min-h-[100px]"
              />
              <Button onClick={handleGenerateImage} disabled={isGeneratingImage || !imagePrompt.trim()}>
                {isGeneratingImage ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ImageIcon className="w-4 h-4 mr-2" />}
                {isGeneratingImage ? "生成中..." : "开始生成"}
              </Button>
              
              {generatedImage && (
                <div className="mt-4 border rounded-lg p-2 bg-muted/20">
                  <img src={generatedImage} alt="Generated" className="w-full h-auto rounded" />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="weather">
          <Card>
            <CardHeader>
              <CardTitle>天气查询</CardTitle>
              <CardDescription>输入行政区划代码查询实时天气（默认 110100 北京）</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <Input 
                  value={districtId}
                  onChange={(e) => setDistrictId(e.target.value)}
                  placeholder="行政区划代码"
                  className="max-w-[200px]"
                />
                <Button onClick={handleCheckWeather} disabled={isCheckingWeather}>
                  {isCheckingWeather ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CloudSun className="w-4 h-4 mr-2" />}
                  查询
                </Button>
              </div>
              
              {weatherData && (
                <div className="mt-4 p-4 border rounded-lg bg-card">
                  <h3 className="font-bold text-lg">{weatherData.location.city} - {weatherData.location.name}</h3>
                  <div className="mt-2 text-2xl text-primary font-bold">{weatherData.now.temp}°C</div>
                  <p className="text-muted-foreground">{weatherData.now.text} | 风力：{weatherData.now.wind_class}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="doc">
          <Card>
            <CardHeader>
              <CardTitle>学习报告导出</CardTitle>
              <CardDescription>VIP专属：将您的做题记录和比赛成绩导出为精美的 Word 文档</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">功能准备中，点击模拟生成导出任务。</p>
              <Button onClick={handleExportDoc}>
                <FileDown className="w-4 h-4 mr-2" />
                导出我的学习报告
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
