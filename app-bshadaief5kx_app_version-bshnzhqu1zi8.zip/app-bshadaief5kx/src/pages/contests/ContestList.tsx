import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Clock, Users } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function ContestList() {
  const { profile } = useAuth();
  const [contests, setContests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadContests() {
      try {
        const { data, error } = await supabase.from('contests').select('*').order('start_time', { ascending: false });
        if (error) throw error;
        setContests(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadContests();
  }, []);

  const getStatus = (start: string, end: string) => {
    const now = new Date();
    const startTime = new Date(start);
    const endTime = new Date(end);
    
    if (now < startTime) return { label: '未开始', variant: 'secondary' as const };
    if (now > endTime) return { label: '已结束', variant: 'outline' as const };
    return { label: '进行中', variant: 'default' as const };
  };

  return (
    <div className="container py-8 max-w-5xl mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Trophy className="h-8 w-8 text-primary" />
          比赛系统
        </h1>
        {profile?.role === 'admin' && (
          <Button asChild>
            <Link to="/admin/contests/create">
              创建比赛
            </Link>
          </Button>
        )}
      </div>

      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">加载中...</div>
        ) : contests.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground border border-dashed rounded-lg">
            暂无比赛安排
          </div>
        ) : (
          contests.map(contest => {
            const status = getStatus(contest.start_time, contest.end_time);
            return (
              <Card key={contest.id}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Link to={`/contests/${contest.id}`} className="text-xl font-bold hover:text-primary transition-colors">
                          {contest.title}
                        </Link>
                        {contest.is_team && <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20"><Users className="w-3 h-3 mr-1"/>团队赛</Badge>}
                        <Badge variant={status.variant} className={status.variant === 'default' ? 'bg-green-600 hover:bg-green-700' : ''}>
                          {status.label}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {contest.description}
                      </div>
                      <div className="flex items-center gap-4 text-sm font-mono text-muted-foreground pt-2">
                        <span className="flex items-center gap-1"><Clock className="w-4 h-4"/> {new Date(contest.start_time).toLocaleString()} - {new Date(contest.end_time).toLocaleString()}</span>
                      </div>
                    </div>
                    <Button asChild variant={status.label === '进行中' ? 'default' : 'outline'} className="w-full md:w-auto shrink-0">
                      <Link to={`/contests/${contest.id}`}>
                        {status.label === '进行中' ? '立即参赛' : '查看详情'}
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
