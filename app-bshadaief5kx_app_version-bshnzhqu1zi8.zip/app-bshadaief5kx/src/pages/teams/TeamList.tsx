import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Users, Plus } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export default function TeamList() {
  const { user } = useAuth();
  const [teams, setTeams] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadTeams() {
      try {
        const { data, error } = await supabase.from('teams').select('*, profiles:created_by(username)').order('created_at', { ascending: false });
        if (error) throw error;
        
        // Count members for each team (mocking it or separate queries. For MVP just show simple text)
        setTeams(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadTeams();
  }, []);

  const handleJoin = async (teamId: string) => {
    if (!user) {
      toast.error("请先登录");
      return;
    }
    try {
      const { error } = await supabase.from('team_members').insert({
        team_id: teamId,
        user_id: user.id
      });
      if (error) {
        if (error.code === '23505') toast.info("您已在团队中");
        else throw error;
      } else {
        toast.success("成功加入团队");
      }
    } catch (err: any) {
      toast.error("加入失败: " + err.message);
    }
  };

  return (
    <div className="container py-8 max-w-5xl mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Users className="h-8 w-8 text-primary" />
          团队系统
        </h1>
        <Button asChild>
          <Link to="/teams/create">
            <Plus className="mr-2 h-4 w-4" /> 创建团队
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {loading ? (
          <div className="col-span-full text-center py-12 text-muted-foreground">加载中...</div>
        ) : teams.length === 0 ? (
          <div className="col-span-full text-center py-12 text-muted-foreground border border-dashed rounded-lg">
            暂无团队，去创建一个吧
          </div>
        ) : (
          teams.map(team => (
            <Card key={team.id} className="flex flex-col">
              <CardHeader>
                <CardTitle className="line-clamp-1">{team.name}</CardTitle>
                <CardDescription className="line-clamp-2 min-h-[40px]">{team.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col justify-end">
                <div className="text-sm text-muted-foreground mb-4">
                  创建者: {team.profiles?.username || '未知'}
                </div>
                <div className="flex gap-2 mt-auto">
                  <Button variant="outline" className="flex-1" asChild>
                    <Link to={`/teams/${team.id}`}>查看详情</Link>
                  </Button>
                  <Button className="flex-1" onClick={() => handleJoin(team.id)}>加入</Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
