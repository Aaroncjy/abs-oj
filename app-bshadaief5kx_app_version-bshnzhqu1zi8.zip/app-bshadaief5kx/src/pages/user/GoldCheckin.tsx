// This will be a simple component integrated into the profile or a separate page. For simplicity, we can create a Checkin button in Profile.
// Let's modify Profile instead of a new page.
