import { useState, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/db/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Camera } from "lucide-react";

export default function Settings() {
  const { user, profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState(profile?.username || "");
  
  // Face recognition states
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const streamRef = useRef<MediaStream | null>(null);

  const updateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ username })
        .eq('id', user.id);
        
      if (error) throw error;
      toast.success("个人信息已更新");
    } catch (err: any) {
      toast.error(err.message || "更新失败");
    } finally {
      setLoading(false);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsCameraActive(true);
      }
    } catch (err) {
      toast.error("无法访问摄像头");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const bindFace = async () => {
    if (!videoRef.current || !canvasRef.current || !isCameraActive || !user) return;

    setLoading(true);
    try {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      if (!context) throw new Error("Could not get canvas context");

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      const base64Image = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];

      const { data, error } = await supabase.functions.invoke('face-user-add', {
        body: {
          image: base64Image,
          image_type: "BASE64",
          user_id: user.id,
          user_info: username,
          liveness_control: "NORMAL",
          quality_control: "NORMAL",
        }
      });

      if (error) throw error;

      if (data.error_code === 0) {
        toast.success("人脸绑定成功！现在您可以使用人脸登录了");
        stopCamera();
      } else {
        toast.error(data.error_msg || "人脸绑定失败");
      }
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "人脸识别过程发生错误");
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="container max-w-4xl mx-auto p-4 md:p-8">
      <h1 className="text-3xl font-bold mb-8">账号设置</h1>
      
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="profile">基本信息</TabsTrigger>
          <TabsTrigger value="security">安全与绑定</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>基本信息</CardTitle>
              <CardDescription>更新您的个人资料</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={updateProfile} className="space-y-4 max-w-md">
                <div className="space-y-2">
                  <Label htmlFor="email">邮箱（不可修改）</Label>
                  <Input id="email" value={user.email} disabled />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="username">用户名</Label>
                  <Input 
                    id="username" 
                    value={username} 
                    onChange={(e) => setUsername(e.target.value)} 
                    required 
                  />
                </div>
                <Button type="submit" disabled={loading}>保存修改</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>人脸识别登录</CardTitle>
              <CardDescription>绑定人脸后可使用人脸快速登录平台</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-start space-y-4">
                <div className="relative w-full max-w-[300px] aspect-square bg-muted rounded-lg overflow-hidden border flex items-center justify-center">
                  {!isCameraActive ? (
                    <div className="flex flex-col items-center text-muted-foreground p-4 text-center">
                      <Camera className="h-12 w-12 mb-2" />
                      <p className="text-sm">点击下方按钮开启摄像头</p>
                    </div>
                  ) : (
                    <video 
                      ref={videoRef} 
                      autoPlay 
                      playsInline 
                      muted 
                      className="w-full h-full object-cover transform -scale-x-100" 
                    />
                  )}
                  <canvas ref={canvasRef} className="hidden" />
                </div>
                
                {!isCameraActive ? (
                  <Button onClick={startCamera}>
                    开启摄像头并绑定
                  </Button>
                ) : (
                  <div className="flex gap-2">
                    <Button onClick={bindFace} disabled={loading}>
                      {loading ? "采集中..." : "确认绑定"}
                    </Button>
                    <Button onClick={stopCamera} variant="outline">
                      取消
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
