import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/db/supabase";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Award, Trophy, Code, Clock, CalendarCheck } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

export default function Profile() {
  const { id } = useParams<{ id: string }>();
  const { user: currentUser } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadProfile() {
  const [checkingIn, setCheckingIn] = useState(false);

  const handleCheckin = async () => {
    if (!currentUser) return;
    setCheckingIn(true);
    try {
      // Very basic check-in logic: just add 5 coins. Real app needs to check last check-in date.
      const { error } = await supabase.rpc('add_coins', { user_id_in: currentUser.id, amount: 5 });
      if (error) throw error;
      
      // Add record
      await supabase.from('gold_records').insert({
        user_id: currentUser.id,
        type: 'checkin',
        amount: 5,
        balance: profile.coins + 5,
        description: '每日签到'
      });
      
      setProfile({...profile, coins: profile.coins + 5});
      toast.success("签到成功！获得 5 金币");
    } catch (err: any) {
      toast.error(err.message || "签到失败");
    } finally {
      setCheckingIn(false);
    }
  };
      if (!id) return;
      try {
        const { data, error } = await supabase
          .from("public_profiles")
          .select("*")
          .eq("id", id)
          .single();
          
        if (error) throw error;
        setProfile(data);
      } catch (error) {
        console.error("Error loading profile:", error);
      } finally {
        setLoading(false);
      }
    }
    
    loadProfile();
  }, [id]);

  if (loading) {
    return <div className="flex h-64 items-center justify-center">加载中...</div>;
  }

  if (!profile) {
    return <div className="flex h-64 items-center justify-center">未找到该用户</div>;
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="grid gap-6 md:grid-cols-[1fr_2fr]">
        <div className="flex flex-col gap-6">
          <Card>
            <CardHeader className="text-center">
              <div className="flex justify-between items-start w-full absolute top-4 px-4">
                {currentUser?.id === profile.id && (
                  <Button variant="outline" size="sm" onClick={handleCheckin} disabled={checkingIn} className="ml-auto">
                    <CalendarCheck className="w-4 h-4 mr-2" />
                    签到领金币
                  </Button>
                )}
              </div>
              <Avatar className="w-24 h-24 mx-auto mb-4 mt-6">
                <AvatarImage src={profile.avatar_url || ""} alt={profile.username} />
                <AvatarFallback className="text-2xl">{profile.username?.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <CardTitle className="text-2xl">{profile.username}</CardTitle>
              <CardDescription className="flex items-center justify-center gap-2 mt-2">
                {profile.is_vip && <Badge variant="default" className="bg-yellow-500 hover:bg-yellow-600">VIP</Badge>}
                {profile.role === 'admin' && <Badge variant="destructive">管理员</Badge>}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground flex items-center gap-1"><Clock className="w-4 h-4" /> 注册时间</span>
                <span>{new Date(profile.created_at).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground flex items-center gap-1"><Award className="w-4 h-4" /> 金币余额</span>
                <span className="font-medium text-yellow-600">{profile.coins}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Trophy className="w-5 h-5 text-primary" /> 获得的勋章
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="border-primary text-primary">萌新报到</Badge>
                {/* Real medals will be fetched from user_medals */}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col gap-6">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Code className="w-5 h-5 text-primary" /> 做题记录
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 mb-8">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-primary">0</div>
                  <div className="text-sm text-muted-foreground mt-1">提交总数</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-green-600">0</div>
                  <div className="text-sm text-muted-foreground mt-1">通过数</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">0%</div>
                  <div className="text-sm text-muted-foreground mt-1">通过率</div>
                </div>
              </div>
              
              <h3 className="font-medium mb-4">最近提交</h3>
              <div className="text-center text-muted-foreground py-8 border border-dashed rounded-lg">
                暂无提交记录
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
