import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect } from "react";
import { Users, FileCode, MessageSquare, Trophy, ShieldAlert, LayoutDashboard } from "lucide-react";
import { toast } from "sonner";

export default function AdminLayout() {
  const { profile, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!loading && profile?.role !== 'admin') {
      toast.error("您没有权限访问此页面");
      navigate("/");
    }
  }, [profile, loading, navigate]);

  if (loading || profile?.role !== 'admin') return null;

  const navItems = [
    { name: "概览", path: "/admin", icon: LayoutDashboard, exact: true },
    { name: "用户管理", path: "/admin/users", icon: Users, exact: false },
    { name: "题目管理", path: "/admin/problems", icon: FileCode, exact: false },
    { name: "帖子管理", path: "/admin/posts", icon: MessageSquare, exact: false },
    { name: "比赛管理", path: "/admin/contests", icon: Trophy, exact: false },
  ];

  return (
    <div className="flex flex-1 overflow-hidden">
      <aside className="w-64 border-r bg-muted/20 hidden md:flex flex-col">
        <div className="p-4 border-b flex items-center gap-2 font-semibold text-destructive">
          <ShieldAlert className="w-5 h-5" />
          管理员控制台
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const isActive = item.exact ? location.pathname === item.path : location.pathname.startsWith(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                  isActive ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-muted"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </aside>
      <main className="flex-1 overflow-auto bg-muted/10 p-6 min-w-0">
        <div className="max-w-5xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
