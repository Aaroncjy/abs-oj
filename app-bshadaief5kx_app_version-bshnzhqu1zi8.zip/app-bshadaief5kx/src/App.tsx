import { BrowserRouter } from "react-router-dom";
import { Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { AppRoutes } from "./routes";

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <TooltipProvider>
          <AppRoutes />
          <Toaster position="top-center" richColors />
        </TooltipProvider>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
