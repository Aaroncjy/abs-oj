import { Routes, Route } from "react-router-dom";
import { MainLayout } from "./components/layouts/MainLayout";
import Home from "./pages/Home";
import Placeholder from "./pages/Placeholder";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import ProblemList from "./pages/problems/ProblemList";
import ProblemCreate from "./pages/problems/ProblemCreate";
import ProblemDetail from "./pages/problems/ProblemDetail";
import ForumHome from "./pages/forum/ForumHome";
import PostCreate from "./pages/forum/PostCreate";
import PostDetail from "./pages/forum/PostDetail";
import TeamList from "./pages/teams/TeamList";
import ContestList from "./pages/contests/ContestList";
import VipPurchase from "./pages/payment/VipPurchase";
import AiTools from "./pages/ai/AiTools";
import Profile from "./pages/user/Profile";
import Settings from "./pages/user/Settings";
import { RouteGuard } from "./components/common/RouteGuard";

export function AppRoutes() {
  return (
    <RouteGuard>
      <Routes>
        <Route element={<MainLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/problems" element={<ProblemList />} />
            <Route index element={<AdminDashboard />} />
          <Route path="/problems/create" element={<ProblemCreate />} />
          <Route path="/problems/:id" element={<ProblemDetail />} />
          <Route path="/forum" element={<ForumHome />} />
          <Route path="/forum/create" element={<PostCreate />} />
          <Route path="/forum/:id" element={<PostDetail />} />
          <Route path="/teams" element={<TeamList />} />
          <Route path="/contests" element={<ContestList />} />
          <Route path="/rankings" element={<Placeholder title="排行榜与勋章" />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/profile/:id" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/vip" element={<VipPurchase />} />
          <Route path="/ai-tools" element={<AiTools />} />
          <Route path="/admin" element={<AdminLayout />}>
            <Route path="*" element={<Placeholder title="管理页面" />} />
          </Route>
          <Route path="*" element={<Home />} />
        </Route>
      </Routes>
    </RouteGuard>
  );
}
