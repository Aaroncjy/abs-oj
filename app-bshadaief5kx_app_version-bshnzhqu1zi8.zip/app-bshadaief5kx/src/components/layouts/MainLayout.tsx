import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Menu, UserCircle, LogOut, Code, Trophy, Users, MessageSquare, Terminal, Award, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/contexts/AuthContext";
import { useState } from "react";

const navItems = [
  { name: "首页", path: "/", icon: Terminal },
  { name: "题库", path: "/problems", icon: Code },
  { name: "论坛", path: "/forum", icon: MessageSquare },
  { name: "团队", path: "/teams", icon: Users },
  { name: "比赛", path: "/contests", icon: Trophy },
  { name: "排行榜", path: "/rankings", icon: Award },
];

export function MainLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = async () => {
    await signOut();
    navigate("/");
  };

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <header className="sticky top-0 z-50 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="shrink-0 md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle navigation menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <nav className="grid gap-6 text-lg font-medium">
              <Link to="/" className="flex items-center gap-2 text-lg font-semibold" onClick={() => setIsOpen(false)}>
                <Terminal className="h-6 w-6 text-primary" />
                <span className="text-primary font-bold">ABSOJ</span>
              </Link>
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-2 ${
                    location.pathname === item.path
                      ? "text-primary font-semibold"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  <item.icon className="h-5 w-5" />
                  {item.name}
                </Link>
              ))}
            </nav>
          </SheetContent>
        </Sheet>
        
        <Link to="/" className="hidden md:flex items-center gap-2 text-lg font-semibold">
          <Terminal className="h-6 w-6 text-primary" />
          <span className="text-primary font-bold tracking-tight">ABSOJ</span>
        </Link>
        
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium ml-6 flex-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`transition-colors ${
                location.pathname === item.path || (item.path !== "/" && location.pathname.startsWith(item.path))
                  ? "text-primary font-semibold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-4 ml-auto md:ml-0 shrink-0">
          {!user ? (
            <>
              <Button variant="ghost" asChild>
                <Link to="/login">登录</Link>
              </Button>
              <Button asChild>
                <Link to="/register">注册</Link>
              </Button>
            </>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  {profile?.avatar_url ? (
                    <img src={profile.avatar_url} alt="Avatar" className="h-8 w-8 rounded-full object-cover" />
                  ) : (
                    <UserCircle className="h-6 w-6" />
                  )}
                  <span className="sr-only">Toggle user menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{profile?.username || '用户'}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                        金币: {profile?.coins || 0}
                      </span>
                      {profile?.is_vip && (
                        <span className="text-xs bg-yellow-500/20 text-yellow-600 px-2 py-0.5 rounded-full font-medium">
                          VIP
                        </span>
                      )}
                    </div>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to={`/profile/${user.id}`} className="cursor-pointer flex items-center w-full">
                    <UserCircle className="mr-2 h-4 w-4" />
                    个人主页
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/settings" className="cursor-pointer flex items-center w-full">
                    <Settings className="mr-2 h-4 w-4" />
                    账号设置
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/vip" className="cursor-pointer flex items-center w-full text-yellow-600 focus:text-yellow-600">
                    <Award className="mr-2 h-4 w-4" />
                    VIP特权
                  </Link>
                </DropdownMenuItem>
                {profile?.is_vip && (
                  <DropdownMenuItem asChild>
                    <Link to="/ai-tools" className="cursor-pointer flex items-center w-full">
                      <Terminal className="mr-2 h-4 w-4" />
                      AI工具箱
                    </Link>
                  </DropdownMenuItem>
                )}
                {profile?.role === 'admin' && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link to="/admin" className="cursor-pointer flex items-center w-full text-primary">
                        <Settings className="mr-2 h-4 w-4" />
                        后台管理
                      </Link>
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  退出登录
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </header>
      
      <main className="flex-1 flex flex-col min-w-0">
        <Outlet />
      </main>
      
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            Built for programmers. © 2026 absoj.cn. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link to="/about" className="hover:text-foreground">关于我们</Link>
            <Link to="/terms" className="hover:text-foreground">用户协议</Link>
            <Link to="/privacy" className="hover:text-foreground">隐私政策</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
