import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const PUBLIC_ROUTES = [
  "/",
  "/login",
  "/register",
  "/problems",
  "/forum",
  "/contests",
  "/teams"
];

export const RouteGuard = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (loading) return;

    // Check if the route is public or explicitly allows guests
    const isPublicRoute = PUBLIC_ROUTES.some(route => 
      location.pathname === route || 
      (route !== "/" && location.pathname.startsWith(`${route}/`))
    );

    if (!user && !isPublicRoute) {
      // Redirect to login if user is not authenticated and route is not public
      navigate("/login", { state: { from: location.pathname } });
    }
  }, [user, loading, location, navigate]);

  if (loading) {
    return <div className="flex h-screen w-full items-center justify-center">Loading...</div>;
  }

  return <>{children}</>;
};
