// edge-functions/location-weather.ts
import { serve } from "https://deno.land/std/http/server.ts";

serve(async (req: Request): Promise<Response> => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  // --- 解析客户端请求 ---
  let latitude: number;
  let longitude: number;
  let dataType: string;
  try {
    const body = await req.json();
    // 支持两种传参方式：
    // 1. 分别传 latitude + longitude（推荐）
    // 2. 直接传 location 字符串（格式：纬度,经度）
    if (body.location) {
      const parts = String(body.location).split(",");
      latitude = parseFloat(parts[0]);
      longitude = parseFloat(parts[1]);
    } else {
      latitude = body.latitude;
      longitude = body.longitude;
    }
    dataType = body.data_type ?? "all";
    if (isNaN(latitude) || isNaN(longitude)) throw new Error("Missing or invalid latitude/longitude");
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  // --- 注入平台密钥（禁止暴露给前端） ---
  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server configuration error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  // --- 调用上游 API ---
  // 注意：location 格式为 纬度,经度
  const url = new URL("https://app-bshadaief5kx-api-GYX1bnRz2Pxa-gateway.appmiaoda.com/weather/v1/");
  url.searchParams.set("location", `${latitude},${longitude}`);
  url.searchParams.set("data_type", dataType);

  const upstream = await fetch(url.toString(), {
    method: "GET",
    headers: {
      "Accept": "application/json",
      "X-Gateway-Authorization": `Bearer ${apiKey}`,
    },
  });

  // 转发配额/余额错误
  if (upstream.status === 429 || upstream.status === 402) {
    const errText = await upstream.text();
    return new Response(errText, {
      status: upstream.status,
      headers: { "Content-Type": "application/json" },
    });
  }

  if (!upstream.ok) {
    return new Response(
      JSON.stringify({ error: `Upstream error: ${upstream.status}` }),
      { status: 502, headers: { "Content-Type": "application/json" } }
    );
  }

  const data = await upstream.json();
  return new Response(JSON.stringify(data), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
});
