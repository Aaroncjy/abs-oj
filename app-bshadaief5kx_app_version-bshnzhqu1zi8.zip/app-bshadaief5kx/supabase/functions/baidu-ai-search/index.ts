// edge-functions/baidu-ai-search.ts
import { serve } from "https://deno.land/std/http/server.ts";

serve(async (req: Request): Promise<Response> => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  // --- 解析客户端请求 ---
  let messages: Array<{ role: string; content: string }>;
  let instruction: string | undefined;
  let enableDeepSearch: boolean | undefined;
  let resourceTypeFilter: Array<{ type: string; top_k: number }> | undefined;
  let searchRecencyFilter: string | undefined;
  let enableReasoning: boolean | undefined;
  let maxCompletionTokens: number | undefined;
  let responseFormat: string | undefined;
  let enableFollowupQueries: boolean | undefined;

  try {
    const body = await req.json();
    messages = body.messages;
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      throw new Error("Missing or invalid messages");
    }
    instruction = body.instruction;
    enableDeepSearch = body.enable_deep_search;
    resourceTypeFilter = body.resource_type_filter;
    searchRecencyFilter = body.search_recency_filter;
    enableReasoning = body.enable_reasoning;
    maxCompletionTokens = body.max_completion_tokens;
    responseFormat = body.response_format;
    enableFollowupQueries = body.enable_followup_queries;
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  // --- 注入平台密钥（严禁暴露给前端） ---
  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server configuration error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  // --- 构建上游请求体（剔除 undefined 字段） ---
  const upstreamBody: Record<string, unknown> = { messages };
  if (instruction !== undefined) upstreamBody.instruction = instruction;
  if (enableDeepSearch !== undefined) upstreamBody.enable_deep_search = enableDeepSearch;
  if (resourceTypeFilter !== undefined) upstreamBody.resource_type_filter = resourceTypeFilter;
  if (searchRecencyFilter !== undefined) upstreamBody.search_recency_filter = searchRecencyFilter;
  if (enableReasoning !== undefined) upstreamBody.enable_reasoning = enableReasoning;
  if (maxCompletionTokens !== undefined) upstreamBody.max_completion_tokens = maxCompletionTokens;
  if (responseFormat !== undefined) upstreamBody.response_format = responseFormat;
  if (enableFollowupQueries !== undefined) upstreamBody.enable_followup_queries = enableFollowupQueries;

  // --- 调用上游（SSE 流式） ---
  const upstream = await fetch(
    "https://app-bshadaief5kx-api-DYJwo27V8Qya-gateway.appmiaoda.com/v2/ai_search/chat/completions",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify(upstreamBody),
    }
  );

  // 透传配额/余额错误
  if (upstream.status === 429 || upstream.status === 402) {
    const errText = await upstream.text();
    return new Response(errText, {
      status: upstream.status,
      headers: { "Content-Type": "application/json" },
    });
  }

  if (!upstream.ok || !upstream.body) {
    return new Response(JSON.stringify({ error: `Upstream error: ${upstream.status}` }), {
      status: 502,
      headers: { "Content-Type": "application/json" },
    });
  }

  // --- 直接 proxy SSE 流，不缓冲 ---
  return new Response(upstream.body, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "X-Content-Type-Options": "nosniff",
    },
  });
});
