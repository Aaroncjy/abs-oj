import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { Wechatpay } from "npm:wechatpay-axios-plugin";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function createWechatPayUrl(
  MERCHANT_ID: string, 
  MERCHANT_APP_ID: string, 
  MCH_CERT_SERIAL_NO: string, 
  MCH_PRIVATE_KEY: string, 
  WECHAT_PAY_PUBLIC_KEY_ID: string, 
  WECHAT_PAY_PUBLIC_KEY: string, 
  outTradeNo: string, 
  amount: number, 
  notifyUrl: string
) {
  try {
    const wxpay = new Wechatpay({
      mchid: MERCHANT_ID,
      serial: MCH_CERT_SERIAL_NO,
      privateKey: MCH_PRIVATE_KEY,
      certs: {[WECHAT_PAY_PUBLIC_KEY_ID]: WECHAT_PAY_PUBLIC_KEY}
    });
    const res = await wxpay.v3.pay.transactions.native.post({
      mchid: MERCHANT_ID,
      out_trade_no: outTradeNo,
      appid: MERCHANT_APP_ID,
      description: 'VIP Membership Purchase',
      notify_url: notifyUrl,
      amount: { total: Math.round(amount * 100) }
    }, { headers: { 'Wechatpay-Serial': WECHAT_PAY_PUBLIC_KEY_ID } });
    if (res.data.code_url) {
      console.log(`[WeChatPay SUCCESS] outTradeNo=${outTradeNo}, url=${res.data.code_url}`);
      return { success: true, url: res.data.code_url };
    } else {
      console.error(`[WeChatPay FAILED] outTradeNo=${outTradeNo}, error=${res.data.message || JSON.stringify(res.data)}`);
      return { success: false, error: res.data.message || JSON.stringify(res.data) };
    }
  } catch (err: any) {
    console.error(`[WeChatPay ERROR] outTradeNo=${outTradeNo}, error=${err?.message || String(err)}`);
    return { success: false, error: err?.message || String(err) };
  }
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { sku_code, quantity } = await req.json();

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: req.headers.get("Authorization")! } } }
    );

    const { data: userData, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !userData.user) throw new Error("Unauthorized");
    const userId = userData.user.id;

    // Admin client to bypass RLS for inventory checking if needed
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Call RPC to manage inventory and get SKU
    const { data: sku, error: skuError } = await supabaseAdmin.rpc('manage_sku_inventory', {
      sku_code_in: sku_code,
      qty_in: quantity,
      action: 'order'
    });

    if (skuError) {
      console.error("SKU error:", skuError);
      throw new Error(`Failed to manage inventory: ${skuError.message}`);
    }

    if (!sku) {
      throw new Error("SKU not found or out of stock");
    }

    const totalAmount = sku.price * quantity;
    const uid = Math.random().toString(36).substring(2, 10);
    const yymmdd = new Date().toISOString().slice(2, 10).replace(/-/g, "");
    const orderNo = `ORD-${yymmdd}-${uid}`;

    const { data: order, error: orderError } = await supabaseAdmin
      .from('orders')
      .insert({
        order_no: orderNo,
        user_id: userId,
        status: 'pending',
        total_amount: totalAmount
      })
      .select()
      .single();

    if (orderError) throw new Error(`Failed to create order: ${orderError.message}`);

    const { error: itemsError } = await supabaseAdmin
      .from('order_items')
      .insert({
        order_id: order.id,
        sku_code: sku.sku_code,
        quantity: quantity,
        unit_price: sku.price,
        total_price: totalAmount,
        sku_snapshot: sku
      });

    if (itemsError) throw new Error(`Failed to create order items: ${itemsError.message}`);

    const MERCHANT_ID = Deno.env.get('MERCHANT_ID');
    const MERCHANT_APP_ID = Deno.env.get('MERCHANT_APP_ID');
    const MCH_CERT_SERIAL_NO = Deno.env.get('MCH_CERT_SERIAL_NO');
    const MCH_PRIVATE_KEY = Deno.env.get('MCH_PRIVATE_KEY');
    const WECHAT_PAY_PUBLIC_KEY_ID = Deno.env.get('WECHAT_PAY_PUBLIC_KEY_ID');
    const WECHAT_PAY_PUBLIC_KEY = Deno.env.get('WECHAT_PAY_PUBLIC_KEY');
    
    if (!MERCHANT_ID || !MERCHANT_APP_ID || !MCH_CERT_SERIAL_NO || !MCH_PRIVATE_KEY || !WECHAT_PAY_PUBLIC_KEY_ID || !WECHAT_PAY_PUBLIC_KEY) {
      return new Response(JSON.stringify({ order_no: orderNo, error: "Missing WeChat Pay configuration" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const notifyUrl = `${Deno.env.get("SUPABASE_URL")}/functions/v1/wechat_payment_webhook`;
    
    const payResult = await createWechatPayUrl(
      MERCHANT_ID, MERCHANT_APP_ID, MCH_CERT_SERIAL_NO, MCH_PRIVATE_KEY.replace(/\\n/g, '\n'),
      WECHAT_PAY_PUBLIC_KEY_ID, WECHAT_PAY_PUBLIC_KEY.replace(/\\n/g, '\n'),
      orderNo, totalAmount, notifyUrl
    );

    if (payResult.success && payResult.url) {
      await supabaseAdmin.from('orders').update({ wechat_pay_url: payResult.url }).eq('id', order.id);
      return new Response(JSON.stringify({ order_no: orderNo, url: payResult.url }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } else {
      throw new Error(`Failed to generate WeChat Pay URL: ${payResult.error}`);
    }
  } catch (error: any) {
    console.error("Error creating payment order:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
