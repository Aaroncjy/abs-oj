// edge-functions/face-user-add.ts
import { serve } from "https://deno.land/std/http/server.ts";

serve(async (req: Request): Promise<Response> => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  let image: string;
  let image_type: string;
  let user_id: string;
  let user_info: string | undefined;
  let quality_control: string | undefined;
  let liveness_control: string | undefined;
  let action_type: string | undefined;

  try {
    const body = await req.json();
    image = body.image;
    image_type = body.image_type;
    user_id = body.user_id;
    if (!image) throw new Error("Missing image");
    if (!image_type) throw new Error("Missing image_type");
    if (!user_id) throw new Error("Missing user_id");
    user_info = body.user_info;
    quality_control = body.quality_control;
    liveness_control = body.liveness_control;
    action_type = body.action_type;
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server configuration error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  const requestBody: Record<string, string> = { image, image_type, user_id };
  if (user_info) requestBody.user_info = user_info;
  if (quality_control) requestBody.quality_control = quality_control;
  if (liveness_control) requestBody.liveness_control = liveness_control;
  if (action_type) requestBody.action_type = action_type;

  const upstream = await fetch(
    "https://app-bshadaief5kx-api-l9nZz8ro7Bl9-gateway.appmiaoda.com/rest/2.0/face/v3/faceset/user/add",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify(requestBody),
    }
  );

  if (upstream.status === 429 || upstream.status === 402) {
    const errText = await upstream.text();
    return new Response(errText, {
      status: upstream.status,
      headers: { "Content-Type": "application/json" },
    });
  }

  if (!upstream.ok) {
    return new Response(
      JSON.stringify({ error: `Upstream error: ${upstream.status}` }),
      { status: 502, headers: { "Content-Type": "application/json" } }
    );
  }

  const data = await upstream.json();
  return new Response(JSON.stringify(data), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
});
