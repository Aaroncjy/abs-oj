// edge-functions/face-search.ts
import { serve } from "https://deno.land/std/http/server.ts";

serve(async (req: Request): Promise<Response> => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  let image: string;
  let image_type: string;
  let quality_control: string | undefined;
  let liveness_control: string | undefined;
  let user_id: string | undefined;
  let max_user_num: number | undefined;
  let match_threshold: number | undefined;

  try {
    const body = await req.json();
    image = body.image;
    image_type = body.image_type;
    if (!image) throw new Error("Missing image");
    if (!image_type) throw new Error("Missing image_type");
    quality_control = body.quality_control;
    liveness_control = body.liveness_control;
    user_id = body.user_id;
    max_user_num = body.max_user_num;
    match_threshold = body.match_threshold;
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server configuration error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  const requestBody: Record<string, string | number> = { image, image_type };
  if (quality_control) requestBody.quality_control = quality_control;
  if (liveness_control) requestBody.liveness_control = liveness_control;
  if (user_id) requestBody.user_id = user_id;
  if (max_user_num !== undefined) requestBody.max_user_num = max_user_num;
  if (match_threshold !== undefined) requestBody.match_threshold = match_threshold;

  const upstream = await fetch(
    "https://app-bshadaief5kx-api-e94GZ5j0PwVa-gateway.appmiaoda.com/rest/2.0/face/v3/search",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify(requestBody),
    }
  );

  if (upstream.status === 429 || upstream.status === 402) {
    const errText = await upstream.text();
    return new Response(errText, {
      status: upstream.status,
      headers: { "Content-Type": "application/json" },
    });
  }

  if (!upstream.ok) {
    return new Response(
      JSON.stringify({ error: `Upstream error: ${upstream.status}` }),
      { status: 502, headers: { "Content-Type": "application/json" } }
    );
  }

  const data = await upstream.json();
  return new Response(JSON.stringify(data), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
});
