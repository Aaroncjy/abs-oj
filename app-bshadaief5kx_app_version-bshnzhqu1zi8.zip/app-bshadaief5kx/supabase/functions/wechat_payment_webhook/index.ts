import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { Aes } from "npm:wechatpay-axios-plugin";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function decryptTradeState(MCH_API_V3_KEY: string, associatedData: string, nonce: string, ciphertext: string) {
  const plaintext = await Aes.AesGcm.decrypt(ciphertext, MCH_API_V3_KEY, nonce, associatedData);
  const obj = JSON.parse(plaintext);
  return {
    status: (obj.trade_state ?? "").toString() === "SUCCESS" ? "SUCCESS" : "OTHERS",
    order_no: obj.out_trade_no ?? ""
  };
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const bodyText = await req.text();
    console.log("Received webhook:", bodyText);
    const body = JSON.parse(bodyText);
    
    if (body.event_type !== 'TRANSACTION.SUCCESS') {
      return new Response("Not a success event", { status: 200 });
    }

    const { resource } = body;
    const { associated_data, nonce, ciphertext } = resource;

    const MCH_API_V3_KEY = Deno.env.get("MCH_API_V3_KEY");
    if (!MCH_API_V3_KEY) throw new Error("Missing MCH_API_V3_KEY");

    const result = await decryptTradeState(MCH_API_V3_KEY, associated_data, nonce, ciphertext);
    
    if (result.status === "SUCCESS" && result.order_no) {
      const supabaseAdmin = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
      );

      // Optimistic locking using status check
      const { data: order, error: orderError } = await supabaseAdmin
        .from('orders')
        .select('*')
        .eq('order_no', result.order_no)
        .eq('status', 'pending')
        .single();
        
      if (orderError || !order) {
        console.log(`Order ${result.order_no} is already processed or not found`);
        return new Response("OK", { status: 200 }); // Acknowledge to WeChat
      }

      // Update to paid
      const { error: updateError } = await supabaseAdmin
        .from('orders')
        .update({ status: 'paid', updated_at: new Date().toISOString() })
        .eq('id', order.id)
        .eq('status', 'pending');

      if (updateError) {
        throw new Error(`Failed to update order status: ${updateError.message}`);
      }

      // Post-payment logic: update SKU, grant VIP
      const { data: orderItems } = await supabaseAdmin
        .from('order_items')
        .select('*')
        .eq('order_id', order.id);

      if (orderItems && orderItems.length > 0) {
        for (const item of orderItems) {
          await supabaseAdmin.rpc('manage_sku_inventory', {
            sku_code_in: item.sku_code,
            qty_in: item.quantity,
            action: 'pay_success'
          });

          // Handle VIP logic
          const months = item.sku_code === 'VIP_1_MONTH' ? 1 : 
                         item.sku_code === 'VIP_3_MONTH' ? 3 : 
                         item.sku_code === 'VIP_12_MONTH' ? 12 : 0;
          
          if (months > 0) {
             const { data: profile } = await supabaseAdmin
              .from('profiles')
              .select('vip_expire_time')
              .eq('id', order.user_id)
              .single();
              
             let newExpire = new Date();
             if (profile && profile.vip_expire_time && new Date(profile.vip_expire_time) > newExpire) {
                newExpire = new Date(profile.vip_expire_time);
             }
             newExpire.setMonth(newExpire.getMonth() + months * item.quantity);
             
             await supabaseAdmin
              .from('profiles')
              .update({ is_vip: true, vip_expire_time: newExpire.toISOString() })
              .eq('id', order.user_id);
          }
        }
      }
    }

    return new Response(JSON.stringify({ code: "SUCCESS", message: "OK" }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (error: any) {
    console.error("Webhook error:", error);
    return new Response(JSON.stringify({ code: "FAIL", message: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
});
